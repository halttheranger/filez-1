minetest.register_node("soda:cocacola", {
	description = "(c@red)c(c@white)o(c@red)c(c@white)a(c@red)-(c@white)c(c@red)o(c@white)l(c@red)a",
	drawtype = "plantlike",
	visual_scale = 1.0,
	tiles = {"cocacola.png"},
	inventory_image = "cocacola.png",
	paramtype = "light",
	sunlight_propagates = true,
	walkable = false,
	is_ground_content = false,
	selection_box = {
		type = "fixed",
		fixed = {-0.2, -0.5, -0.2, 0.2, 0, 0.2}
	},
	groups = {fleshy = 3, dig_immediate = 3, flammable = 2},
	on_use = minetest.item_eat(2),
})
minetest.register_node("soda:creamsoda", {
	description = "(c@LightSalmon)creamsoda",
	drawtype = "plantlike",
	visual_scale = 1.0,
	tiles = {"creamsoda.png"},
	inventory_image = "creamsoda.png",
	paramtype = "light",
	sunlight_propagates = true,
	walkable = false,
	is_ground_content = false,
	selection_box = {
		type = "fixed",
		fixed = {-0.2, -0.5, -0.2, 0.2, 0, 0.2}
	},
	groups = {fleshy = 3, dig_immediate = 3, flammable = 2},
	on_use = minetest.item_eat(2),
})
minetest.register_node("soda:drpepper", {
	description = "(c@red)Dr.Pepper",
	drawtype = "plantlike",
	visual_scale = 1.0,
	tiles = {"drpepper.png"},
	inventory_image = "drpepper.png",
	paramtype = "light",
	sunlight_propagates = true,
	walkable = false,
	is_ground_content = false,
	selection_box = {
		type = "fixed",
		fixed = {-0.2, -0.5, -0.2, 0.2, 0, 0.2}
	},
	groups = {fleshy = 3, dig_immediate = 3, flammable = 2},
	on_use = minetest.item_eat(2),
})
minetest.register_node("soda:fanta", {
	description = "(c@orange)Fanta (Orange)",
	drawtype = "plantlike",
	visual_scale = 1.0,
	tiles = {"fanta.png"},
	inventory_image = "fanta.png",
	paramtype = "light",
	sunlight_propagates = true,
	walkable = false,
	is_ground_content = false,
	selection_box = {
		type = "fixed",
		fixed = {-0.2, -0.5, -0.2, 0.2, 0, 0.2}
	},
	groups = {fleshy = 3, dig_immediate = 3, flammable = 2},
	on_use = minetest.item_eat(2),
})
minetest.register_node("soda:joltcola", {
	description = "(c@brown)Jolt Cola",
	drawtype = "plantlike",
	visual_scale = 1.0,
	tiles = {"joltcola.png"},
	inventory_image = "joltcola.png",
	paramtype = "light",
	sunlight_propagates = true,
	walkable = false,
	is_ground_content = false,
	selection_box = {
		type = "fixed",
		fixed = {-0.2, -0.5, -0.2, 0.2, 0, 0.2}
	},
	groups = {fleshy = 3, dig_immediate = 3, flammable = 2},
	on_use = minetest.item_eat(2),
})
minetest.register_node("soda:pepsi", {
	description = "(c@navy)Pepsi",
	drawtype = "plantlike",
	visual_scale = 1.0,
	tiles = {"pepsi.png"},
	inventory_image = "pepsi.png",
	paramtype = "light",
	sunlight_propagates = true,
	walkable = false,
	is_ground_content = false,
	selection_box = {
		type = "fixed",
		fixed = {-0.2, -0.5, -0.2, 0.2, 0, 0.2}
	},
	groups = {fleshy = 3, dig_immediate = 3, flammable = 2},
	on_use = minetest.item_eat(2),
})
minetest.register_node("soda:rootbeer", {
	description = "(c@black)Rootbeer",
	drawtype = "plantlike",
	visual_scale = 1.0,
	tiles = {"rootbeer.png"},
	inventory_image = "rootbeer.png",
	paramtype = "light",
	sunlight_propagates = true,
	walkable = false,
	is_ground_content = false,
	selection_box = {
		type = "fixed",
		fixed = {-0.2, -0.5, -0.2, 0.2, 0, 0.2}
	},
	groups = {fleshy = 3, dig_immediate = 3, flammable = 2},
	on_use = minetest.item_eat(2),
})
minetest.register_node("soda:sprite", {
	description = "(c@green)Sprite",
	drawtype = "plantlike",
	visual_scale = 1.0,
	tiles = {"sprite.png"},
	inventory_image = "sprite.png",
	paramtype = "light",
	sunlight_propagates = true,
	walkable = false,
	is_ground_content = false,
	selection_box = {
		type = "fixed",
		fixed = {-0.2, -0.5, -0.2, 0.2, 0, 0.2}
	},
	groups = {fleshy = 3, dig_immediate = 3, flammable = 2},
	on_use = minetest.item_eat(2),
})





