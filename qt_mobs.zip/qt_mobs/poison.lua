
minetest.register_craftitem(":qt:turtle_shell", {
	description = "Mutant Turtle Shell",
	inventory_image = "turtle_shell.png",
})


qt_mobs:register_mob(":qt:skeleton_poison", {
	type = "monster",
	hp_max = 30,
	collisionbox = {-0.4, -1, -0.4, 0.4, 1, 0.4},
	visual = "mesh",
	mesh = "basic_zombie.x",
	textures = {"skeleton_poison.png"},
	visual_size = {x=1, y=1},
	makes_footstep_sound = true,
	view_range = 30,
	walk_velocity = 1.5,
	run_velocity = 2.2,
	damage = 30,
	drops ={
		{name = "qt:bone",
		chance = 1,
		min = 1,
		max = 4,},
		{name = "qt:soul",
		chance = 2,
		min = 1,
		max = 1,},
	},
	armor = 100,
	drawtype = "front",
	water_damage = 0,
	lava_damage = 0,
	light_damage = 0,
	on_rightclick = nil,
	attack_type = "dogfight",
	animation = {
		speed_normal = 15,
		speed_run = 15,
		stand_start = 0,
		stand_end = 79,
		walk_start = 168,
		walk_end = 188,
		run_start = 168,
		run_end = 188,
		punch_start = 0,
		punch_end = 79,
	},
	allience = "zombie",
	sounds = {
		random = "skeleton",
	},
})

qt_mobs:register_spawn("qt:skeleton_poison", {"qt:poison_stone", "qt:poison_dirt", "qt:poison_dirt_with_grass", "group:poison_plant"}, 7, -1, 1000, 3, -890)

minetest.register_craftitem(":qt:spawn_skeleton_poison", {
	description = "Spawn Poison Skeleton",
	inventory_image = "spawn_skeleton.png",
	liquids_pointable = false,
	stack_max = 99,
	on_place = function(itemstack, placer, pointed_thing)
		if pointed_thing.type == "node" then
			local p = pointed_thing.above
			p.y = p.y+1
			minetest.env:add_entity(p, "qt:skeleton_poison")
			if not minetest.setting_getbool("creative_mode") then itemstack:take_item() end
			return itemstack
		end
	end,
})

minetest.register_node(":qt:spawner_skeleton_poison", {
	description = "Poison Skeleton Spawner",
	paramtype = "light",
	tiles = {"poison_skeleton_spawner.png"},
	is_ground_content = true,
	drawtype = "allfaces",
	groups = {cracky=1,level=1},
	drop = "default:steel_ingot",
})

if not minetest.setting_getbool("only_peaceful_mobs") then
 minetest.register_abm({
	nodenames = {"qt:spawner_skeleton_poison"},
	interval = 2.0,
	chance = 20,
	action = function(pos, node, active_object_count, active_object_count_wider)
		local player_near = false
		local mobs = 0
		for  _,obj in ipairs(minetest.env:get_objects_inside_radius(pos, 30)) do
			if obj:is_player() then
				player_near = true
			else
				if obj:get_luaentity().name == "qt:skeleton_poison" then mobs = mobs + 1 end
			end
		end
		if player_near then
			if mobs < 8 then
				pos.x = pos.x+1
				local p = minetest.find_node_near(pos, 5, {"air"})
				--p.y = p.y+1
				local ll = minetest.env:get_node_light(p)
				local wtime = minetest.env:get_timeofday()
				if not ll then return end
				if ll > 8 then return end
				if ll < -1 then return end
				if minetest.env:get_node(p).name ~= "air" then return end
				p.y = p.y+1
				if minetest.env:get_node(p).name ~= "air" then return end
				if (wtime > 0.2 and wtime < 0.805) and pos.y > 0 then return end
				p.y = p.y-1
				minetest.env:add_entity(p, "qt:skeleton_poison")
			end
		end
	end
 })
end

qt_mobs:register_mob(":qt:skeleton_poison_advanced", {
	type = "monster",
	hp_max = 30,
	collisionbox = {-0.4, -1, -0.4, 0.4, 1, 0.4},
	visual = "mesh",
	mesh = "basic_zombie.x",
	textures = {"skeleton_poison_advanced.png"},
	visual_size = {x=1, y=1},
	makes_footstep_sound = true,
	view_range = 30,
	walk_velocity = 1.3,
	run_velocity = 2.0,
	damage = 30,
	drops = {
		{name = "qt:bone",
		chance = 1,
		min = 1,
		max = 4,},
		{name = "qt:soul",
		chance = 2,
		min = 1,
		max = 1,},
	},
	armor = 90,
	drawtype = "front",
	water_damage = 0,
	lava_damage = 0,
	light_damage = 5,
	on_rightclick = nil,
	attack_type = "dogfight",
	animation = {
		speed_normal = 15,
		speed_run = 15,
		stand_start = 0,
		stand_end = 79,
		walk_start = 168,
		walk_end = 188,
		run_start = 168,
		run_end = 188,
		punch_start = 0,
		punch_end = 79,
	},
	allience = "zombie",
	sounds = {
		random = "skeleton",
	},
})

qt_mobs:register_spawn("qt:skeleton_poison_advanced", {"qt:poison_stone", "qt:poison_dirt", "qt:poison_dirt_with_grass", "group:poison_plant"}, 7, -1, 100, 3, -890)

minetest.register_craftitem(":qt:spawn_skeleton_poison_advanced", {
	description = "Spawn Poison Skeleton Advanced",
	inventory_image = "spawn_skeleton.png",
	liquids_pointable = false,
	stack_max = 99,
	on_place = function(itemstack, placer, pointed_thing)
		if pointed_thing.type == "node" then
			local p = pointed_thing.above
			p.y = p.y+1
			minetest.env:add_entity(p, "qt:skeleton_poison_advanced")
			if not minetest.setting_getbool("creative_mode") then itemstack:take_item() end
			return itemstack
		end
	end,
})

minetest.register_node(":qt:spawner_skeleton_poison_advanced", {
	description = "Poison Skeleton Advanced Spawner",
	paramtype = "light",
	tiles = {"poison_skeleton_spawner.png"},
	is_ground_content = true,
	drawtype = "allfaces",
	groups = {cracky=1,level=1},
	drop = "default:steel_ingot",
})

if not minetest.setting_getbool("only_peaceful_mobs") then
 minetest.register_abm({
	nodenames = {"qt:spawner_skeleton_poison_advanced"},
	interval = 2.0,
	chance = 20,
	action = function(pos, node, active_object_count, active_object_count_wider)
		local player_near = false
		local mobs = 0
		for  _,obj in ipairs(minetest.env:get_objects_inside_radius(pos, 30)) do
			if obj:is_player() then
				player_near = true
			else
				if obj:get_luaentity().name == "qt:skeleton_poison_advanced" then mobs = mobs + 1 end
			end
		end
		if player_near then
			if mobs < 8 then
				pos.x = pos.x+1
				local p = minetest.find_node_near(pos, 5, {"air"})
				--p.y = p.y+1
				local ll = minetest.env:get_node_light(p)
				local wtime = minetest.env:get_timeofday()
				if not ll then return end
				if ll > 8 then return end
				if ll < -1 then return end
				if minetest.env:get_node(p).name ~= "air" then return end
				p.y = p.y+1
				if minetest.env:get_node(p).name ~= "air" then return end
				if (wtime > 0.2 and wtime < 0.805) and pos.y > 0 then return end
				p.y = p.y-1
				minetest.env:add_entity(p, "qt:skeleton_poison_advanced")
			end
		end
	end
 })
end

qt_mobs:register_mob(":qt:mutant_turtle_baby", {
	type = "monster",
	hp_max = 125,
	collisionbox = {-0.45, -0.27, -0.45, 0.45, 0.4, 0.45},
	visual = "mesh",
	mesh = "bug_alt.x",
	textures = {"bug_img.png"},
	visual_size = {x=6, y=6},
	makes_footstep_sound = true,
	view_range = 30,
	walk_velocity = 0.5,
	run_velocity = 0.7,
	damage = 50,
	drops = {
		{name = "qt:turtle_shell",
		chance = 1,
		min = 1,
		max = 4,},
		{name = "qt:soul",
		chance = 2,
		min = 1,
		max = 1,},
	},
	armor = 80,
	drawtype = "front",
	water_damage = 0,
	lava_damage = 0,
	light_damage = 5,
	on_rightclick = nil,
	attack_type = "dogfight",
	animation = {
		speed_normal = 15,
		speed_run = 15,
		stand_start = 1,
		stand_end = 1,
		walk_start = 1,
		walk_end = 37,
		run_start = 1,
		run_end = 37,
		punch_start = 40,
		punch_end = 59,
	},
	--sounds = {
	--	random = "skeleton",
	--},
})

qt_mobs:register_spawn("qt:mutant_turtle_baby", {"qt:poison_stone", "qt:poison_dirt", "qt:poison_dirt_with_grass", "group:poison_plant"}, 7, -1, 1100, 3, -890)

minetest.register_craftitem(":qt:spawn_mutant_turtle_baby", {
	description = "Spawn Baby Mutant Turtle",
	inventory_image = "spawn_zombie.png",
	liquids_pointable = false,
	stack_max = 99,
	on_place = function(itemstack, placer, pointed_thing)
		if pointed_thing.type == "node" then
			local p = pointed_thing.above
			p.y = p.y+1
			minetest.env:add_entity(p, "qt:mutant_turtle_baby")
			if not minetest.setting_getbool("creative_mode") then itemstack:take_item() end
			return itemstack
		end
	end,
})

minetest.register_node(":qt:spawner_mutant_turtle_baby", {
	description = "Mutant Turtle Baby Spawner",
	paramtype = "light",
	tiles = {"turtle_spawner.png"},
	is_ground_content = true,
	drawtype = "allfaces",
	groups = {cracky=1,level=1},
	drop = "default:steel_ingot",
})

if not minetest.setting_getbool("only_peaceful_mobs") then
 minetest.register_abm({
	nodenames = {"qt:spawner_mutant_turtle_baby"},
	interval = 2.0,
	chance = 20,
	action = function(pos, node, active_object_count, active_object_count_wider)
		local player_near = false
		local mobs = 0
		for  _,obj in ipairs(minetest.env:get_objects_inside_radius(pos, 30)) do
			if obj:is_player() then
				player_near = true
			else
				if obj:get_luaentity().name == "qt:mutant_turtle_baby" then mobs = mobs + 1 end
			end
		end
		if player_near then
			if mobs < 8 then
				pos.x = pos.x+1
				local p = minetest.find_node_near(pos, 5, {"air"})
				--p.y = p.y+1
				local ll = minetest.env:get_node_light(p)
				local wtime = minetest.env:get_timeofday()
				if not ll then return end
				if ll > 8 then return end
				if ll < -1 then return end
				if minetest.env:get_node(p).name ~= "air" then return end
				p.y = p.y+1
				if minetest.env:get_node(p).name ~= "air" then return end
				if (wtime > 0.2 and wtime < 0.805) and pos.y > 0 then return end
				p.y = p.y-1
				minetest.env:add_entity(p, "qt:mutant_turtle_baby")
			end
		end
	end
 })
end

qt_mobs:register_mob(":qt:mutant_turtle", {
	type = "monster",
	hp_max = 500,
	collisionbox = {-0.7, -0.45, -0.7, 0.7, 0.6, 0.7},
	visual = "mesh",
	mesh = "bug_alt.x",
	textures = {"bug_img.png"},
	visual_size = {x=15, y=15},
	makes_footstep_sound = true,
	view_range = 60,
	walk_velocity = 0.8,
	run_velocity = 1.0,
	damage = 65,
	drops = {
		{name = "qt:turtle_shell",
		chance = 1,
		min = 5,
		max = 10,},
		{name = "qt:soul",
		chance = 2,
		min = 1,
		max = 1,},
	},
	armor = 80,
	drawtype = "front",
	water_damage = 0,
	lava_damage = 0,
	light_damage = 5,
	on_rightclick = nil,
	attack_type = "dogfight",
	animation = {
		speed_normal = 15,
		speed_run = 15,
		stand_start = 0,
		stand_end = 0,
		walk_start = 0,
		walk_end = 75,
		run_start = 0,
		run_end = 75,
		punch_start = 0,
		punch_end = 0,
	},
	--sounds = {
	--	random = "skeleton",
	--},
})

qt_mobs:register_spawn("qt:mutant_turtle", {"qt:poison_stone", "qt:poison_dirt", "qt:poison_dirt_with_grass", "group:poison_plant"}, 7, -1, 1800, 3, -890)

minetest.register_craftitem(":qt:spawn_mutant_turtle", {
	description = "Spawn Mutant Turtle",
	inventory_image = "spawn_zombie.png",
	liquids_pointable = false,
	stack_max = 99,
	on_place = function(itemstack, placer, pointed_thing)
		if pointed_thing.type == "node" then
			local p = pointed_thing.above
			p.y = p.y+1
			minetest.env:add_entity(p, "qt:mutant_turtle")
			if not minetest.setting_getbool("creative_mode") then itemstack:take_item() end
			return itemstack
		end
	end,
})

minetest.register_node(":qt:spawner_mutant_turtle", {
	description = "Mutant Turtle Spawner",
	paramtype = "light",
	tiles = {"turtle_spawner.png"},
	is_ground_content = true,
	drawtype = "allfaces",
	groups = {cracky=1,level=1},
	drop = "default:steel_ingot",
})

if not minetest.setting_getbool("only_peaceful_mobs") then
 minetest.register_abm({
	nodenames = {"qt:spawner_mutant_turtle"},
	interval = 2.0,
	chance = 20,
	action = function(pos, node, active_object_count, active_object_count_wider)
		local player_near = false
		local mobs = 0
		for  _,obj in ipairs(minetest.env:get_objects_inside_radius(pos, 30)) do
			if obj:is_player() then
				player_near = true
			else
				if obj:get_luaentity().name == "qt:mutant_turtle" then mobs = mobs + 1 end
			end
		end
		if player_near then
			if mobs < 8 then
				pos.x = pos.x+1
				local p = minetest.find_node_near(pos, 5, {"air"})
				--p.y = p.y+1
				local ll = minetest.env:get_node_light(p)
				local wtime = minetest.env:get_timeofday()
				if not ll then return end
				if ll > 8 then return end
				if ll < -1 then return end
				if minetest.env:get_node(p).name ~= "air" then return end
				p.y = p.y+1
				if minetest.env:get_node(p).name ~= "air" then return end
				if (wtime > 0.2 and wtime < 0.805) and pos.y > 0 then return end
				p.y = p.y-1
				minetest.env:add_entity(p, "qt:mutant_turtle")
			end
		end
	end
 })
end

--qt_mobs:register_spawn("qt:", {"qt:poison_stone", "qt:poison_dirt", "qt:poison_dirt_with_grass"}, 7, -1, 900, 3, -890)

--[[
qt_mobs:register_mob(":qt:bug", {
	type = "animal",
	hp_max = 5,
	collisionbox = {-0.5, -0.27, -0.5, 0.5, 0.4, 0.5},
	textures = {"bug_img.png"},
	visual = "mesh",
	mesh = "bug_alt.x",
	visual_size = {x=60, y=60},
	makes_footstep_sound = true,
	walk_velocity = 1,
	armor = 200,
	drops = {
		{name = "qt:soul",
		chance = 2,
		min = 1,
		max = 1,},
	},
	drawtype = "front",
	water_damage = 0,
	lava_damage = 5,
	light_damage = 0,
	animation = {
		speed_normal = 15,
		stand_start = 1,
		stand_end = 1,
		walk_start = 1,
		walk_end = 75,
	},
	follow = "farming:wheat",
	view_range = 5,
	sounds = {
		--random = "sheep",
	},
	on_rightclick = nil,
})

minetest.register_craftitem(":qt:spawn_bug", {
	description = "Spawn Bug",
	inventory_image = "spawn_pig.png",
	liquids_pointable = false,
	stack_max = 99,
	on_place = function(itemstack, placer, pointed_thing)
		if pointed_thing.type == "node" then
			local p = pointed_thing.above
			p.y = p.y+1
			minetest.env:add_entity(p, "qt:bug")
			if not minetest.setting_getbool("creative_mode") then itemstack:take_item() end
			return itemstack
		end
	end,
})
--]]


