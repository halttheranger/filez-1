qt_mobs:register_mob(":qt:pig", {
	type = "animal",
	hp_max = 5,
	collisionbox = {-0.4, -0.01, -0.4, 0.4, 1, 0.4},
	textures = {"pig.png"},
	visual = "mesh",
	mesh = "pig.x",
	visual_size = {x=6, y=6},
	makes_footstep_sound = true,
	walk_velocity = 1,
	armor = 200,
	drops = {
		{name = "qt:meat_raw",
		chance = 1,
		min = 2,
		max = 3,},
		{name = "qt:soul",
		chance = 2,
		min = 1,
		max = 1,},
	},
	drawtype = "front",
	water_damage = 0,
	lava_damage = 5,
	light_damage = 0,
	animation = {
		speed_normal = 0,
		stand_start = 0,
		stand_end = 0,
		walk_start = 0,
		walk_end = 0,
	},
	follow = "farming:wheat",
	view_range = 5,
	sounds = {
		--random = "sheep",
	},
	on_rightclick = nil,
})

minetest.register_craftitem(":qt:spawn_pig", {
	description = "Spawn Pig",
	inventory_image = "spawn_pig.png",
	liquids_pointable = false,
	stack_max = 99,
	on_place = function(itemstack, placer, pointed_thing)
		if pointed_thing.type == "node" then
			local p = pointed_thing.above
			p.y = p.y+1
			minetest.env:add_entity(p, "qt:pig")
			if not minetest.setting_getbool("creative_mode") then itemstack:take_item() end
			return itemstack
		end
	end,
})


qt_mobs:register_mob(":qt:snowman", {
	type = "animal",
	hp_max = 15,
	collisionbox = {-0.4, -0.01, -0.4, 0.4, 2, 0.4},
	textures = {"snowman.png"},
	visual = "mesh",
	mesh = "snowman.x",
	visual_size = {x=6, y=6},
	makes_footstep_sound = true,
	walk_velocity = 1,
	armor = 100,
	drops = {
		{name = "default:snow",
		chance = 1,
		min = 2,
		max = 3,},
		{name = "qt:soul",
		chance = 2,
		min = 1,
		max = 1,},
	},
	drawtype = "front",
	water_damage = 10,
	lava_damage = 50,
	light_damage = 0,
	animation = {
		speed_normal = 0,
		stand_start = 0,
		stand_end = 0,
		walk_start = 0,
		walk_end = 0,
	},
	view_range = 5,
	sounds = {
		--random = "sheep",
	},
	on_rightclick = nil,
})

qt_mobs:register_spawn("qt:snowman", {"default:snow", "default:snowblock", "default:dirt_with_snow"}, 14, -1, 900, 3, 500)

minetest.register_craftitem(":qt:spawn_snowman", {
	description = "Spawn Snowman",
	inventory_image = "spawn_sheep.png",
	liquids_pointable = false,
	stack_max = 99,
	on_place = function(itemstack, placer, pointed_thing)
		if pointed_thing.type == "node" then
			local p = pointed_thing.above
			p.y = p.y+1
			minetest.env:add_entity(p, "qt:snowman")
			if not minetest.setting_getbool("creative_mode") then itemstack:take_item() end
			return itemstack
		end
	end,
})




--[[
qt_mobs:register_mob(":qt:testmob", {
	type = "monster",
	hp_max = 30,
	collisionbox = {-0.4, -1, -0.4, 0.4, 1, 0.4},
	visual = "mesh",
	mesh = "human.x",
	textures = {"criminal.png"},
	visual_size = {x=1, y=1},
	makes_footstep_sound = true,
	view_range = 15,
	walk_velocity = 1,
	run_velocity = 1.5,
	damage = 1,
	drops = {
		{name = "qt:soul",
		chance = 2,
		min = 1,
		max = 1,},
	},
	armor = 125,
	drawtype = "front",
	water_damage = 0,
	lava_damage = 5,
	light_damage = 0,
	on_rightclick = nil,
	attack_type = "dogfight",
	animation = {
		speed_normal = 15,
		speed_run = 15,
		stand_start = 0,
		stand_end = 79,
		walk_start = 168,
		walk_end = 188,
		run_start = 168,
		run_end = 188,
		punch_start = 189,
		punch_end = 198,
	},
	arrow = "qt:ghost_droid_x2_laser",
	shoot_interval = 3,
	allience = "criminal",
	sounds = {
		random = "criminal_laugh",
	},
	custom_vals = {
	timer_message = "Timer!"
	},
	on_step_function = function(self)
		local hp = self.object:get_hp()
		if hp <= 10 and self.attack_type ~= "shoot" then
			self.attack_type = "shoot"
			minetest.debug("state changed")
		end
	end,
	timer = 1,
	on_timer_function = function(self)
		--minetest.debug(self.custom_vals.timer_message)
		--local hp = self.object:get_hp()
		--hp = hp + 4
		--if hp > 30 then hp = 30 end
		--self.object:set_hp(hp)
	end,
})

minetest.register_craftitem(":qt:spawn_testmob", {
	description = "Spawn Testmob",
	inventory_image = "spawn_criminal.png",
	liquids_pointable = false,
	stack_max = 99,
	on_place = function(itemstack, placer, pointed_thing)
		if pointed_thing.type == "node" then
			local p = pointed_thing.above
			p.y = p.y+1
			minetest.env:add_entity(p, "qt:testmob")
			if not minetest.setting_getbool("creative_mode") then itemstack:take_item() end
			return itemstack
		end
	end,
})
--]]
