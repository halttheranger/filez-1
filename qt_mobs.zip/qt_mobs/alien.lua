
minetest.register_craftitem(":qt:alien_hide", {
	description = "Alien Hide",
	inventory_image = "alien_hide.png",
})

qt_mobs:register_mob(":qt:alien_peaceful", {
	type = "animal",
	hp_max = 50,
	collisionbox = {-0.4, -1, -0.4, 0.4, 1.3, 0.4},
	visual = "mesh",
	mesh = "alien.x",
	textures = {"alien.png"},
	visual_size = {x=6, y=6},
	makes_footstep_sound = true,
	view_range = 15,
	walk_velocity = 1,
	run_velocity = 1.5,
	damage = 1,
	drops = {
		{name = "qt:soul",
		chance = 2,
		min = 1,
		max = 1,},
		{name = "qt:alien_hide",
		chance = 1,
		min = 1,
		max = 4,},
	},
	armor = 100,
	drawtype = "front",
	water_damage = 0,
	lava_damage = 3,
	light_damage = 0,
	on_rightclick = nil,
	animation = {
		speed_normal = 0,
		speed_run = 0,
		stand_start = 0,
		stand_end = 0,
		walk_start = 0,
		walk_end = 0,
		run_start = 0,
		run_end = 0,
		punch_start = 0,
		punch_end = 0,
	},

})

qt_mobs:register_spawn("qt:alien_peaceful", {"qt:etheral_dirt_with_grass", "qt:etheral_dirt", "qt:etheral_sand", "qt:etheral_stone"}, 14, -1, 1500, 3, 2700)

minetest.register_craftitem(":qt:spawn_alien_peaceful", {
	description = "Spawn Peaceful Alien",
	inventory_image = "spawn_alien.png",
	liquids_pointable = false,
	stack_max = 99,
	on_place = function(itemstack, placer, pointed_thing)
		if pointed_thing.type == "node" then
			local p = pointed_thing.above
			p.y = p.y+1
			minetest.env:add_entity(p, "qt:alien_peaceful")
			if not minetest.setting_getbool("creative_mode") then itemstack:take_item() end
			return itemstack
		end
	end,
})

minetest.register_node(":qt:spawner_alien_peaceful", {
	description = "Peaceful Alien Spawner",
	paramtype = "light",
	tiles = {"alien_spawner.png"},
	is_ground_content = true,
	drawtype = "allfaces",
	groups = {cracky=1,level=1},
	drop = "default:steel_ingot",
})


minetest.register_abm({
	nodenames = {"qt:spawner_alien_peaceful"},
	interval = 2.0,
	chance = 20,
	action = function(pos, node, active_object_count, active_object_count_wider)
		local player_near = false
		local mobs = 0
		for  _,obj in ipairs(minetest.env:get_objects_inside_radius(pos, 30)) do
			if obj:is_player() then
				player_near = true
			else
				if obj:get_luaentity().name == "qt:alien_peaceful" then mobs = mobs + 1 end
			end
		end
		if player_near then
			if mobs < 8 then
				pos.x = pos.x+1
				local p = minetest.find_node_near(pos, 5, {"air"})
				--p.y = p.y+1
				local ll = minetest.env:get_node_light(p)
				if not ll then return end
				if ll > 20 then return end
				if ll < 8 then return end
				if minetest.env:get_node(p).name ~= "air" then return end
				p.y = p.y+1
				if minetest.env:get_node(p).name ~= "air" then return end
				p.y = p.y-1
				minetest.env:add_entity(p, "qt:alien_peaceful")
			end
		end
	end
})


qt_mobs:register_mob(":qt:alien_shooter", {
	type = "monster",
	hp_max = 50,
	collisionbox = {-0.4, -1, -0.4, 0.4, 1.3, 0.4},
	visual = "mesh",
	mesh = "alien.x",
	textures = {"alien_military.png"},
	visual_size = {x=6, y=6},
	makes_footstep_sound = true,
	view_range = 15,
	walk_velocity = 1,
	run_velocity = 3,
	damage = 4,
	drops = {
		{name = "qt:soul",
		chance = 2,
		min = 1,
		max = 1,},
		{name = "qt:alien_hide",
		chance = 1,
		min = 1,
		max = 4,},
	},
	armor = 90,
	drawtype = "front",
	water_damage = 0,
	lava_damage = 3,
	light_damage = 0,
	on_rightclick = nil,
	attack_type = "shoot",
	arrow = "qt:alien_ray",
	shoot_interval = 2.5,
	sounds = {
		--attack = "",
	},
	animation = {
		stand_start = 0,
		stand_end = 19,
		walk_start = 20,
		walk_end = 35,
		punch_start = 36,
		punch_end = 48,
		speed_normal = 15,
		speed_run = 15,
	},
})

qt_mobs:register_spawn("qt:alien_shooter", {"qt:etheral_dirt_with_grass", "qt:etheral_dirt", "qt:etheral_sand", "qt:etheral_stone"}, 3, -1, 1500, 3, 2700)

qt_mobs:register_arrow(":qt:alien_ray", {
	visual = "sprite",
	visual_size = {x=1, y=1},
	textures = {"alien_ray.png"},
	velocity = 5,
	hit_player = function(self, player)
		local s = self.object:getpos()
		local p = player:getpos()
		local vec = {x=s.x-p.x, y=s.y-p.y, z=s.z-p.z}
		player:punch(self.object, 1.0,  {
			full_punch_interval=1.0,
			damage_groups = {fleshy=25},
		}, vec)
	end,
	hit_node = function(self, pos, node)
	end
})

minetest.register_craftitem(":qt:spawn_alien_shooter", {
	description = "Spawn Shooting Alien",
	inventory_image = "spawn_alien.png",
	liquids_pointable = false,
	stack_max = 99,
	on_place = function(itemstack, placer, pointed_thing)
		if pointed_thing.type == "node" then
			local p = pointed_thing.above
			p.y = p.y+1
			minetest.env:add_entity(p, "qt:alien_shooter")
			if not minetest.setting_getbool("creative_mode") then itemstack:take_item() end
			return itemstack
		end
	end,
})

minetest.register_node(":qt:spawner_alien_shooter", {
	description = "Shooting Alien Spawner",
	paramtype = "light",
	tiles = {"alien_spawner.png"},
	is_ground_content = true,
	drawtype = "allfaces",
	groups = {cracky=1,level=1},
	drop = "default:steel_ingot",
})


minetest.register_abm({
	nodenames = {"qt:spawner_alien_shooter"},
	interval = 2.0,
	chance = 20,
	action = function(pos, node, active_object_count, active_object_count_wider)
		local player_near = false
		local mobs = 0
		for  _,obj in ipairs(minetest.env:get_objects_inside_radius(pos, 30)) do
			if obj:is_player() then
				player_near = true
			else
				if obj:get_luaentity().name == "qt:alien_shooter" then mobs = mobs + 1 end
			end
		end
		if player_near then
			if mobs < 8 then
				pos.x = pos.x+1
				local p = minetest.find_node_near(pos, 5, {"air"})
				--p.y = p.y+1
				local ll = minetest.env:get_node_light(p)
				if not ll then return end
				if ll > 20 then return end
				if ll < 8 then return end
				if minetest.env:get_node(p).name ~= "air" then return end
				p.y = p.y+1
				if minetest.env:get_node(p).name ~= "air" then return end
				p.y = p.y-1
				minetest.env:add_entity(p, "qt:alien_shooter")
			end
		end
	end
})

qt_mobs:register_mob(":qt:droid_gost_x1", {
	type = "monster",
	hp_max = 25,
	collisionbox = {-0.4, -2, -0.4, 0.4, 1, 0.4},
	visual = "mesh",
	mesh = "ghost_droid_1.x",
	textures = {"ghost_droid_1.png"},
	visual_size = {x=5, y=5},
	makes_footstep_sound = true,
	view_range = 15,
	walk_velocity = 1,
	run_velocity = 1.5,
	damage = 1,
	drops = {
		{name = "qt:corilium_ingot",
		chance = 1,
		min = 3,
		max = 6,},
		{name = "qt:soul",
		chance = 2,
		min = 1,
		max = 1,},
	},
	armor = 100,
	drawtype = "front",
	water_damage = 0,
	lava_damage = 0,
	light_damage = 0,
	on_rightclick = nil,
	attack_type = "shoot",
	arrow = "qt:ghost_droid_x1_laser",
	shoot_interval = 3,
	animation = {
		speed_normal = 0,
		speed_run = 0,
		stand_start = 0,
		stand_end = 0,
		walk_start = 0,
		walk_end = 0,
		run_start = 0,
		run_end = 0,
		punch_start = 0,
		punch_end = 0,
	},
	allience = "robots",
})

qt_mobs:register_spawn("qt:droid_gost_x1", {"qt:etheral_dirt_with_grass", "qt:etheral_dirt", "qt:etheral_sand", "qt:etheral_stone"}, 3, -1, 1500, 3, 2700)

qt_mobs:register_arrow(":qt:ghost_droid_x1_laser", {
	visual = "sprite",
	visual_size = {x=1, y=1},
	textures = {"robot_laser_ball.png"},
	velocity = 5,
	hit_player = function(self, player)
		local s = self.object:getpos()
		local p = player:getpos()
		local vec = {x=s.x-p.x, y=s.y-p.y, z=s.z-p.z}
		player:punch(self.object, 1.0,  {
			full_punch_interval=1.0,
			damage_groups = {fleshy=20},
		}, vec)
	end,
	hit_node = function(self, pos, node)
	end
})

minetest.register_craftitem(":qt:spawn_droid_gost_x1", {
	description = "Spawn Ghost Droid X1",
	inventory_image = "spawn_zombie.png",
	liquids_pointable = false,
	stack_max = 99,
	on_place = function(itemstack, placer, pointed_thing)
		if pointed_thing.type == "node" then
			local p = pointed_thing.above
			p.y = p.y+2
			minetest.env:add_entity(p, "qt:droid_gost_x1")
			if not minetest.setting_getbool("creative_mode") then itemstack:take_item() end
			return itemstack
		end
	end,
})

minetest.register_node(":qt:spawner_droid_gost_x1", {
	description = "Ghost Droid X1 Spawner",
	paramtype = "light",
	tiles = {"droid_spawner.png"},
	is_ground_content = true,
	drawtype = "allfaces",
	groups = {cracky=1,level=1},
	drop = "default:steel_ingot",
})


minetest.register_abm({
	nodenames = {"qt:spawner_droid_gost_x1"},
	interval = 2.0,
	chance = 20,
	action = function(pos, node, active_object_count, active_object_count_wider)
		local player_near = false
		local mobs = 0
		for  _,obj in ipairs(minetest.env:get_objects_inside_radius(pos, 30)) do
			if obj:is_player() then
				player_near = true
			else
				if obj:get_luaentity().name == "qt:droid_gost_x1" then mobs = mobs + 1 end
			end
		end
		if player_near then
			if mobs < 8 then
				pos.x = pos.x+1
				local p = minetest.find_node_near(pos, 5, {"air"})
				--p.y = p.y+1
				local ll = minetest.env:get_node_light(p)
				if not ll then return end
				if ll > 20 then return end
				if ll < 8 then return end
				if minetest.env:get_node(p).name ~= "air" then return end
				p.y = p.y+1
				if minetest.env:get_node(p).name ~= "air" then return end
				p.y = p.y-1
				minetest.env:add_entity(p, "qt:droid_gost_x1")
			end
		end
	end
})

qt_mobs:register_mob(":qt:droid_gost_x2", {
	type = "monster",
	hp_max = 50,
	collisionbox = {-0.4, -2, -0.4, 0.4, 1, 0.4},
	visual = "mesh",
	mesh = "ghost_droid_1.x",
	textures = {"ghost_droid_1.png"},
	visual_size = {x=5, y=5},
	makes_footstep_sound = true,
	view_range = 15,
	walk_velocity = 1,
	run_velocity = 1.5,
	damage = 1,
	drops = {
		{name = "qt:corilium_ingot",
		chance = 1,
		min = 3,
		max = 6,},
		{name = "qt:soul",
		chance = 2,
		min = 1,
		max = 1,},
	},
	armor = 100,
	drawtype = "front",
	water_damage = 0,
	lava_damage = 0,
	light_damage = 0,
	on_rightclick = nil,
	attack_type = "shoot",
	arrow = "qt:ghost_droid_x2_laser",
	shoot_interval = 3,
	animation = {
		speed_normal = 0,
		speed_run = 0,
		stand_start = 0,
		stand_end = 0,
		walk_start = 0,
		walk_end = 0,
		run_start = 0,
		run_end = 0,
		punch_start = 0,
		punch_end = 0,
	},
	allience = "robots",
})

qt_mobs:register_spawn("qt:droid_gost_x2", {"qt:etheral_dirt_with_grass", "qt:etheral_dirt", "qt:etheral_sand", "qt:etheral_stone"}, 3, -1, 1500, 3, 2700)

qt_mobs:register_arrow(":qt:ghost_droid_x2_laser", {
	visual = "sprite",
	visual_size = {x=1, y=1},
	textures = {"robot_laser_ball.png"},
	velocity = 5,
	hit_player = function(self, player)
		local s = self.object:getpos()
		local p = player:getpos()
		local vec = {x=s.x-p.x, y=s.y-p.y, z=s.z-p.z}
		player:punch(self.object, 1.0,  {
			full_punch_interval=1.0,
			damage_groups = {fleshy=30},
		}, vec)
	end,
	hit_node = function(self, pos, node)
	end
})

minetest.register_craftitem(":qt:spawn_droid_gost_x2", {
	description = "Spawn Ghost Droid X2",
	inventory_image = "spawn_zombie.png",
	liquids_pointable = false,
	stack_max = 99,
	on_place = function(itemstack, placer, pointed_thing)
		if pointed_thing.type == "node" then
			local p = pointed_thing.above
			p.y = p.y+2
			minetest.env:add_entity(p, "qt:droid_gost_x2")
			if not minetest.setting_getbool("creative_mode") then itemstack:take_item() end
			return itemstack
		end
	end,
})

minetest.register_node(":qt:spawner_droid_gost_x2", {
	description = "Ghost Droid X2 Spawner",
	paramtype = "light",
	tiles = {"droid_spawner.png"},
	is_ground_content = true,
	drawtype = "allfaces",
	groups = {cracky=1,level=1},
	drop = "default:steel_ingot",
})


minetest.register_abm({
	nodenames = {"qt:spawner_droid_gost_x2"},
	interval = 2.0,
	chance = 20,
	action = function(pos, node, active_object_count, active_object_count_wider)
		local player_near = false
		local mobs = 0
		for  _,obj in ipairs(minetest.env:get_objects_inside_radius(pos, 30)) do
			if obj:is_player() then
				player_near = true
			else
				if obj:get_luaentity().name == "qt:droid_gost_x2" then mobs = mobs + 1 end
			end
		end
		if player_near then
			if mobs < 8 then
				pos.x = pos.x+1
				local p = minetest.find_node_near(pos, 5, {"air"})
				--p.y = p.y+1
				local ll = minetest.env:get_node_light(p)
				if not ll then return end
				if ll > 20 then return end
				if ll < 8 then return end
				if minetest.env:get_node(p).name ~= "air" then return end
				p.y = p.y+1
				if minetest.env:get_node(p).name ~= "air" then return end
				p.y = p.y-1
				minetest.env:add_entity(p, "qt:droid_gost_x2")
			end
		end
	end
})
