#Minetest Mod Broomstick

By paly2  
With the participation of Crabman and Mg  

This mod add a magic item : the broomstick.
Craft :  
`default:stick` `default:stick` `farming:wheat`

It depends of mana, default and farming.

It you click with a broomstick, you can fly during 2 minutes. 10 seconds before the end, a message will be send to you.


If the server crash, when it will restart, every old users of broomstick will forfeit the fly privilege.
