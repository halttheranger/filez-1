minetest.register_craftitem(":qt:soul_reaper_gem", {
	description = "Soul Reaping Gem",
	inventory_image = "soul_reaper_gem.png",
})

qt_mobs:register_mob(":qt:zombie_nether", {
	type = "monster",
	hp_max = 15,
	collisionbox = {-0.4, -1, -0.4, 0.4, 1, 0.4},
	visual = "mesh",
	mesh = "basic_zombie.x",
	textures = {"nether_zombie.png"},
	visual_size = {x=1, y=1},
	makes_footstep_sound = true,
	view_range = 17,
	walk_velocity = 1.2,
	run_velocity = 1.8,
	damage = 15,
	drops = {
		{name = "qt:rotten_flesh",
		chance = 1,
		min = 1,
		max = 4,},
		{name = "qt:soul",
		chance = 2,
		min = 1,
		max = 1,},
	},
	armor = 110,
	drawtype = "front",
	water_damage = 10,
	lava_damage = 0,
	light_damage = 0,
	on_rightclick = nil,
	attack_type = "dogfight",
	animation = {
		speed_normal = 15,
		speed_run = 15,
		stand_start = 0,
		stand_end = 79,
		walk_start = 168,
		walk_end = 188,
		run_start = 168,
		run_end = 188,
		punch_start = 0,
		punch_end = 79,
	},
	allience = "zombie",
	sounds = {
		random = "undead_mob_grunt",
	},
})

qt_mobs:register_spawn("qt:zombie_nether", {"qt:nether_stone", "qt:nether_sand"}, 7, -1, 900, 3, -600)

minetest.register_craftitem(":qt:spawn_nether_zombie", {
	description = "Spawn Nether Zombie",
	inventory_image = "spawn_nether_zombie.png",
	liquids_pointable = false,
	stack_max = 99,
	on_place = function(itemstack, placer, pointed_thing)
		if pointed_thing.type == "node" then
			local pos = pointed_thing.above
			pos.y = pos.y+1
			minetest.env:add_entity(pos, "qt:zombie_nether")
			if not minetest.setting_getbool("creative_mode") then itemstack:take_item() end
			return itemstack
		end
	end,
})

minetest.register_node(":qt:spawner_nether_zombie", {
	description = "Nether Zombie Spawner",
	paramtype = "light",
	tiles = {"zombie_spawner.png"},
	is_ground_content = true,
	drawtype = "allfaces",
	groups = {cracky=1,level=1},
	drop = "default:steel_ingot",
})

if not minetest.setting_getbool("only_peaceful_mobs") then
 minetest.register_abm({
	nodenames = {"qt:spawner_nether_zombie"},
	interval = 2.0,
	chance = 20,
	action = function(pos, node, active_object_count, active_object_count_wider)
		local poslayer_near = false
		local mobs = 0
		for  _,obj in ipairs(minetest.env:get_objects_inside_radius(pos, 30)) do
			if obj:is_player() then
				player_near = true
			else
				if obj:get_luaentity().name == "qt:zombie_nether" then mobs = mobs + 1 end
			end
		end
		if player_near then
			if mobs < 8 then
				pos.x = pos.x+1
				local pos = minetest.find_node_near(pos, 5, {"air"})
				--pos.y = pos.y+1
				local ll = minetest.env:get_node_light(pos)
				local wtime = minetest.env:get_timeofday()
				if not ll then return end
				if ll > 8 then return end
				if ll < -1 then return end
				if minetest.env:get_node(pos).name ~= "air" then return end
				pos.y = pos.y+1
				if minetest.env:get_node(pos).name ~= "air" then return end
				if (wtime > 0.2 and wtime < 0.805) and pos.y > 0 then return end
				pos.y = pos.y-1
				minetest.env:add_entity(pos, "qt:zombie_nether")
			end
		end
	end
 })
end


qt_mobs:register_mob(":qt:zombie_nether_armored", {
	type = "monster",
	hp_max = 15,
	collisionbox = {-0.4, -1, -0.4, 0.4, 1, 0.4},
	visual = "mesh",
	mesh = "basic_zombie.x",
	textures = {"nether_zombie_armored.png"},
	visual_size = {x=1, y=1},
	makes_footstep_sound = true,
	view_range = 17,
	walk_velocity = 1.2,
	run_velocity = 1.8,
	damage = 15,
	drops = {
		{name = "qt:rotten_flesh",
		chance = 1,
		min = 1,
		max = 4,},
		{name = "qt:soul",
		chance = 2,
		min = 1,
		max = 1,},
	},
	armor = 95,
	drawtype = "front",
	water_damage = 5,
	lava_damage = 0,
	light_damage = 0,
	on_rightclick = nil,
	attack_type = "dogfight",
	animation = {
		speed_normal = 15,
		speed_run = 15,
		stand_start = 0,
		stand_end = 79,
		walk_start = 168,
		walk_end = 188,
		run_start = 168,
		run_end = 188,
		punch_start = 0,
		punch_end = 79,
	},
	allience = "zombie",
	sounds = {
		random = "undead_mob_grunt",
	},
})

qt_mobs:register_spawn("qt:zombie_nether_armored", {"qt:nether_stone", "qt:nether_sand"}, 7, -1, 900, 3, -600)

minetest.register_craftitem(":qt:spawn_nether_zombie_armored", {
	description = "Spawn Armored Nether Zombie",
	inventory_image = "spawn_nether_zombie.png",
	liquids_pointable = false,
	stack_max = 99,
	on_place = function(itemstack, placer, pointed_thing)
		if pointed_thing.type == "node" then
			local pos = pointed_thing.above
			pos.y = pos.y+1
			minetest.env:add_entity(pos, "qt:zombie_nether_armored")
			if not minetest.setting_getbool("creative_mode") then itemstack:take_item() end
			return itemstack
		end
	end,
})

minetest.register_node(":qt:spawner_nether_zombie_armored", {
	description = "Armored Nether Zombie Spawner",
	paramtype = "light",
	tiles = {"zombie_spawner.png"},
	is_ground_content = true,
	drawtype = "allfaces",
	groups = {cracky=1,level=1},
	drop = "default:steel_ingot",
})

if not minetest.setting_getbool("only_poseaceful_mobs") then
 minetest.register_abm({
	nodenames = {"qt:sposawner_nether_zombie_armored"},
	interval = 2.0,
	chance = 20,
	action = function(posos, node, active_object_count, active_object_count_wider)
		local pososlayer_near = false
		local mobs = 0
		for  _,obj in iposairs(minetest.env:get_objects_inside_radius(posos, 30)) do
			if obj:is_poslayer() then
				poslayer_near = true
			else
				if obj:get_luaentity().name == "qt:zombie_nether_armored" then mobs = mobs + 1 end
			end
		end
		if poslayer_near then
			if mobs < 8 then
				posos.x = posos.x+1
				local posos = minetest.find_node_near(posos, 5, {"air"})
				--pos.y = pos.y+1
				local ll = minetest.env:get_node_light(pos)
				local wtime = minetest.env:get_timeofday()
				if not ll then return end
				if ll > 8 then return end
				if ll < -1 then return end
				if minetest.env:get_node(pos).name ~= "air" then return end
				pos.y = pos.y+1
				if minetest.env:get_node(pos).name ~= "air" then return end
				if (wtime > 0.2 and wtime < 0.805) and posos.y > 0 then return end
				pos.y = pos.y-1
				minetest.env:add_entity(pos, "qt:zombie_nether_armored")
			end
		end
	end
 })
end

qt_mobs:register_mob(":qt:demon", {
	type = "monster",
	hp_max = 150,
	collisionbox = {-0.4, -1, -0.4, 0.4, 1, 0.4},
	visual = "mesh",
	mesh = "human.x",
	textures = {"demon.png"},
	visual_size = {x=1, y=1},
	makes_footstep_sound = true,
	view_range = 5,
	walk_velocity = 1,
	run_velocity = 1.5,
	damage = 30,
	drops = {
		{name = "qt:soul",
		chance = 2,
		min = 1,
		max = 1,},
		{name = "qt:soul_reaper_gem",
		chance = 3,
		min = 1,
		max = 3,},
	},
	armor = 100,
	drawtype = "front",
	water_damage = 0,
	lava_damage = 0,
	light_damage = 0,
	on_rightclick = nil,
	attack_type = "dogfight",
	animation = {
		speed_normal = 15,
		speed_run = 15,
		stand_start = 0,
		stand_end = 79,
		walk_start = 168,
		walk_end = 188,
		run_start = 168,
		run_end = 188,
		punch_start = 189,
		punch_end = 198,
	},
	sounds = {
		random = "",
	},
})
qt_mobs:register_spawn("qt:demon", {"qt:nether_stone", "qt:nether_sand"}, 7, -1, 9000, 3, -600)

minetest.register_craftitem(":qt:spawn_demon", {
	description = "Spawn Demon",
	inventory_image = "spawn_skeleton_carbonized.png",
	liquids_pointable = false,
	stack_max = 99,
	on_place = function(itemstack, placer, pointed_thing)
		if pointed_thing.type == "node" then
			local pos = pointed_thing.above
			pos.y = pos.y+1
			minetest.env:add_entity(pos, "qt:demon")
			if not minetest.setting_getbool("creative_mode") then itemstack:take_item() end
			return itemstack
		end
	end,
})

minetest.register_node(":qt:spawner_demon", {
	description = "Demon Spawner",
	paramtype = "light",
	tiles = {"carbonized_skeleton_spawner.png"},
	is_ground_content = true,
	drawtype = "allfaces",
	groups = {cracky=1,level=1},
	drop = "default:steel_ingot",
})

if not minetest.setting_getbool("only_poseaceful_mobs") then
 minetest.register_abm({
	nodenames = {"qt:sposawner_demon"},
	interval = 2.0,
	chance = 20,
	action = function(posos, node, active_object_count, active_object_count_wider)
		local pososlayer_near = false
		local mobs = 0
		for  _,obj in iposairs(minetest.env:get_objects_inside_radius(posos, 30)) do
			if obj:is_poslayer() then
				poslayer_near = true
			else
				if obj:get_luaentity().name == "qt:demon" then mobs = mobs + 1 end
			end
		end
		if poslayer_near then
			if mobs < 8 then
				posos.x = posos.x+1
				local posos = minetest.find_node_near(posos, 5, {"air"})
				--pos.y = pos.y+1
				local ll = minetest.env:get_node_light(pos)
				local wtime = minetest.env:get_timeofday()
				if not ll then return end
				if ll > 20 then return end
				if ll < 8 then return end
				if minetest.env:get_node(pos).name ~= "air" then return end
				pos.y = pos.y+1
				if minetest.env:get_node(pos).name ~= "air" then return end
				if (wtime > 0.2 and wtime < 0.805) and posos.y > 0 then return end
				pos.y = pos.y-1
				minetest.env:add_entity(pos, "qt:demon")
			end
		end
	end
 })
end

minetest.register_node(":qt:spawnnode_demon", {
	description = "Demon Spawn Node",
	tiles = {"carbonized_skeleton_spawner.png"},
	is_ground_content = false,
	groups = {cracky=1,},
	on_punch = function(pos, node, puncher)
		minetest.remove_node(pos)
		minetest.add_entity({x = pos.x, y = pos.y+1, z = pos.z}, "qt:demon")
	end,
})

qt_mobs:register_mob(":qt:firestorm", {
	type = "monster",
	hp_max = 50,
	collisionbox = {-0.7, -0.01, -0.7, 0.7, 3.3, 0.7},
	visual = "mesh",
	mesh = "firestorm.x",
	textures = {"firestorm.png"},
	visual_size = {x=6, y=6},
	makes_footstep_sound = true,
	view_range = 15,
	walk_velocity = 1,
	run_velocity = 3,
	damage = 20,
	drops = {
		{name = "fire:basic_flame",
		chance = 1,
		min = 2,
		max = 3,},
		{name = "qt:soul",
		chance = 2,
		min = 1,
		max = 1,},
	},
	armor = 80,
	drawtype = "front",
	water_damage = 10000000,
	lava_damage = 0,
	light_damage = 0,
	on_rightclick = nil,
	attack_type = "shoot",
	arrow = "qt:firecharge_shot",
	shoot_interval = 2.5,
	sounds = {
		--attack = "",
	},
	animation = {
		stand_start = 0,
		stand_end = 19,
		walk_start = 20,
		walk_end = 35,
		punch_start = 36,
		punch_end = 48,
		speed_normal = 15,
		speed_run = 15,
	},
})

qt_mobs:register_spawn("qt:firestorm", {"qt:nether_stone", "qt:nether_sand"}, 7, -1, 2000, 3, -600)


qt_mobs:register_arrow(":qt:firecharge_shot", {
	visual = "sprite",
	visual_size = {x=1, y=1},
	textures = {"firecharge.png"},
	velocity = 5,
	hit_player = function(self, player)
		local s = self.object:getpos()
		local pos = player:getpos()
		local vec = {x=s.x-pos.x, y=s.y-pos.y, z=s.z-pos.z}
		player:punch(self.object, 1.0,  {
			full_punch_interval=1.0,
			damage_groups = {fleshy=20},
		}, vec)
	end,
	hit_node = function(self, pos, node)
	end
})

minetest.register_craftitem(":qt:spawn_firestorm", {
	description = "Spawn Firestorm",
	inventory_image = "spawn_nether_zombie.png",
	liquids_pointable = false,
	stack_max = 99,
	on_place = function(itemstack, placer, pointed_thing)
		if pointed_thing.type == "node" then
			local pos = pointed_thing.above
			pos.y = pos.y+1
			minetest.env:add_entity(pos, "qt:firestorm")
			if not minetest.setting_getbool("creative_mode") then itemstack:take_item() end
			return itemstack
		end
	end,
})

minetest.register_node(":qt:spawner_firestorm", {
	description = "Firestorm Spawner",
	paramtype = "light",
	tiles = {"firestorm_spawner.png"},
	is_ground_content = true,
	drawtype = "allfaces",
	groups = {cracky=1,level=1},
	drop = "default:steel_ingot",
})


minetest.register_abm({
	nodenames = {"qt:sposawner_firestorm"},
	interval = 2.0,
	chance = 20,
	action = function(pos, node, active_object_count, active_object_count_wider)
		local pososlayer_near = false
		local mobs = 0
		for  _,obj in iposairs(minetest.env:get_objects_inside_radius(pos, 30)) do
			if obj:is_poslayer() then
				poslayer_near = true
			else
				if obj:get_luaentity().name == "qt:firestorm" then mobs = mobs + 1 end
			end
		end
		if poslayer_near then
			if mobs < 8 then
				pos.x = pos.x+1
				local posos = minetest.find_node_near(pos, 5, {"air"})
				--pos.y = pos.y+1
				local ll = minetest.env:get_node_light(pos)
				local wtime = minetest.env:get_timeofday()
				if not ll then return end
				if ll > 20 then return end
				if ll < 8 then return end
				if minetest.env:get_node(pos).name ~= "air" then return end
				pos.y = pos.y+1
				if minetest.env:get_node(pos).name ~= "air" then return end
				if (wtime > 0.2 and wtime < 0.805) and pos.y > 0 then return end
				pos.y = pos.y-1
				minetest.env:add_entity(pos, "qt:firestorm")
			end
		end
	end
})


qt_mobs:register_mob(":qt:boss_nether_golem", {
	type = "monster",
	hp_max = 200,
	collisionbox = {-0.4, -0.01, -0.4, 0.4, 1.9, 0.4},
	visual = "mesh",
	mesh = "basic_golem.x",
	textures = {"nether_golem.png"},
	visual_size = {x=3, y=2.6},
	makes_footstep_sound = true,
	view_range = 30,
	walk_velocity = 1,
	run_velocity = 1.5,
	damage = 35,
	drops = {

		{name = "qt:soul",
		chance = 2,
		min = 1,
		max = 1,},
		{name = "qt:netherite_gem",
		chance = 1,
		min = 2,
		max = 5,},
	},
	armor = 80,
	drawtype = "front",
	water_damage = 100,
	lava_damage = 0,
	light_damage = 0,
	on_rightclick = nil,
	attack_type = "dogfight",
	animation = {
		speed_normal = 15,
		speed_run = 15,
		stand_start = 0,
		stand_end = 14,
		walk_start = 15,
		walk_end = 38,
		run_start = 15,
		run_end = 38,
		punch_start = 15,
		punch_end = 38,
	},
	sounds = {
		--random = "living_sand",
	},
})

minetest.register_craftitem(":qt:spawn_boss_nether_golem", {
	description = "Spawn Nether Golem Boss",
	inventory_image = "spawn_nether_zombie.png",
	liquids_pointable = false,
	stack_max = 99,
	on_place = function(itemstack, placer, pointed_thing)
		if pointed_thing.type == "node" then
			local pos = pointed_thing.above
			pos.y = pos.y+1
			minetest.env:add_entity(pos, "qt:boss_nether_golem")
			if not minetest.setting_getbool("creative_mode") then itemstack:take_item() end
			return itemstack
		end
	end,
})

minetest.register_craft({
	output = 'qt:spawn_boss_nether_golem',
	recipe = {
		{'qt:soul', 'qt:nether_sand', ''},
		{'qt:nether_sand', 'qt:nether_stone', 'qt:nether_sand'},
		{'', 'qt:nether_sand', ''},
	}
})

minetest.register_node(":qt:spawner_boss_nether_golem", {
	description = "Nether Golem Spawner",
	paramtype = "light",
	tiles = {"living_sand_spawner.png"},
	is_ground_content = true,
	drawtype = "allfaces",
	groups = {cracky=1,level=1},
	drop = "default:steel_ingot",
})

if not minetest.setting_getbool("only_peaceful_mobs") then
 minetest.register_abm({
	nodenames = {"qt:spawner_boss_nether_golem"},
	interval = 2.0,
	chance = 20,
	action = function(pos, node, active_object_count, active_object_count_wider)
		local poslayer_near = false
		local mobs = 0
		for  _,obj in ipairs(minetest.env:get_objects_inside_radius(pos, 30)) do
			if obj:is_player() then
				player_near = true
			else
				if obj:get_luaentity().name == "qt:boss_nether_golem" then mobs = mobs + 1 end
			end
		end
		if player_near then
			if mobs < 8 then
				pos.x = pos.x+1
				local pos = minetest.find_node_near(pos, 5, {"air"})
				--pos.y = pos.y+1
				local ll = minetest.env:get_node_light(pos)
				local wtime = minetest.env:get_timeofday()
				if not ll then return end
				if ll > 20 then return end
				if ll < -1 then return end
				if minetest.env:get_node(pos).name ~= "air" then return end
				pos.y = pos.y+1
				if minetest.env:get_node(pos).name ~= "air" then return end
				if (wtime > 0.2 and wtime < 0.805) and pos.y > 0 then return end
				pos.y = pos.y-1
				minetest.env:add_entity(pos, "qt:boss_nether_golem")
			end
		end
	end
 })
end

qt_mobs:register_mob(":qt:boss_firey_knight", {
	type = "monster",
	hp_max = 300,
	collisionbox = {-0.4, -1, -0.4, 0.4, 1, 0.4},
	visual = "mesh",
	--mesh = "knight.obj",
	mesh = "knight.x",
	-- b/c something is wrong with the animations in knight.x
	textures = {"knight1.png"},
	visual_size = {x=1, y=1},
	makes_footstep_sound = true,
	view_range = 50,
	walk_velocity = 1,
	run_velocity = 1.8,
	damage = 45,
	drops = {

		{name = "qt:soul",
		chance = 2,
		min = 1,
		max = 1,},
		{name = "qt:netherite_gem",
		chance = 1,
		min = 10,
		max = 30,},
	},
	armor = 80,
	drawtype = "front",
	water_damage = 1,
	lava_damage = 1,
	light_damage = 0,
	on_rightclick = nil,
	attack_type = "dogfight",
	animation = {
		speed_normal = 15,
		speed_run = 15,
		stand_start = 0,
		stand_end = 79,
		walk_start = 168,
		walk_end = 188,
		run_start = 168,
		run_end = 188,
		punch_start = 189,
		punch_end = 198,
	},
	sounds = {
		--random = "living_sand",
	},
})

minetest.register_craftitem(":qt:spawn_boss_firey_knight", {
	description = "Spawn Firey Knight Boss",
	inventory_image = "spawn_nether_zombie.png",
	liquids_pointable = false,
	stack_max = 99,
	on_place = function(itemstack, placer, pointed_thing)
		if pointed_thing.type == "node" then
			local pos = pointed_thing.above
			pos.y = pos.y+1
			minetest.env:add_entity(pos, "qt:boss_firey_knight")
			if not minetest.setting_getbool("creative_mode") then itemstack:take_item() end
			return itemstack
		end
	end,
})

minetest.register_craft({
	output = 'qt:spawn_boss_firey_knight',
	recipe = {
		{'qt:soul', 'qt:firegold', 'qt:gold_sword'},
		{'qt:firegold', 'qt:netherite_gem', 'qt:firegold'},
		{'', 'qt:firegold', ''},
	}
})

minetest.register_node(":qt:spawner_boss_firey_knight", {
	description = "Firey Knight Spawner",
	paramtype = "light",
	tiles = {"knight_spawner.png"},
	is_ground_content = true,
	drawtype = "allfaces",
	groups = {cracky=1,level=1},
	drop = "default:steel_ingot",
})

if not minetest.setting_getbool("only_peaceful_mobs") then
 minetest.register_abm({
	nodenames = {"qt:spawner_boss_firey_knight"},
	interval = 2.0,
	chance = 20,
	action = function(pos, node, active_object_count, active_object_count_wider)
		local poslayer_near = false
		local mobs = 0
		for  _,obj in ipairs(minetest.env:get_objects_inside_radius(pos, 30)) do
			if obj:is_player() then
				player_near = true
			else
				if obj:get_luaentity().name == "qt:boss_firey_knight" then mobs = mobs + 1 end
			end
		end
		if player_near then
			if mobs < 8 then
				pos.x = pos.x+1
				local pos = minetest.find_node_near(pos, 5, {"air"})
				--pos.y = pos.y+1
				local ll = minetest.env:get_node_light(pos)
				local wtime = minetest.env:get_timeofday()
				if not ll then return end
				if ll > 20 then return end
				if ll < -1 then return end
				if minetest.env:get_node(pos).name ~= "air" then return end
				pos.y = pos.y+1
				if minetest.env:get_node(pos).name ~= "air" then return end
				if (wtime > 0.2 and wtime < 0.805) and pos.y > 0 then return end
				pos.y = pos.y-1
				minetest.env:add_entity(pos, "qt:boss_firey_knight")
			end
		end
	end
 })
end
