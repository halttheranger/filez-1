minetest.register_node (":music:evil_laugh", {
    description = "test sound" ,
    tiles = {
        "captam1.png" , "captam2.png" , "captam3.png" ,
        "captam4.png" , "captam5.png" , "captam6.png" ,
    } ,

    on_rightclick = function (pos, node, player, pointed_thing)
        local pos = player:getpos()
        minetest.sound_play ("evil_laugh",
            { pos=pos, gain = 2.0, max_hear_distance = 5000 })
    end
})
minetest.register_node (":music:cannon_in_d", {
    description = "test sound" ,
    tiles = {
        "captam1.png" , "captam2.png" , "captam3.png" ,
        "captam4.png" , "captam5.png" , "captam6.png" ,
    } ,

    on_rightclick = function (pos, node, player, pointed_thing)
        local pos = player:getpos()
        minetest.sound_play ("cannon_in_d",
            { pos=pos, gain = 2.0, max_hear_distance = 5000 })
    end
})
minetest.register_node (":music:dramatic", {
    description = "test sound" ,
    tiles = {
        "captam1.png" , "captam2.png" , "captam3.png" ,
        "captam4.png" , "captam5.png" , "captam6.png" ,
    } ,

    on_rightclick = function (pos, node, player, pointed_thing)
        local pos = player:getpos()
        minetest.sound_play ("dramatic_music",
            { pos=pos, gain = 2.0, max_hear_distance = 5000 })
    end
})
minetest.register_node (":music:sad", {
    description = "test sound" ,
    tiles = {
        "captam1.png" , "captam2.png" , "captam3.png" ,
        "captam4.png" , "captam5.png" , "captam6.png" ,
    } ,

    on_rightclick = function (pos, node, player, pointed_thing)
        local pos = player:getpos()
        minetest.sound_play ("sad",
            { pos=pos, gain = 2.0, max_hear_distance = 5000 })
    end
})minetest.register_node (":music:skittles", {
    description = "test sound" ,
    tiles = {
        "captam1.png" , "captam2.png" , "captam3.png" ,
        "captam4.png" , "captam5.png" , "captam6.png" ,
    } ,

    on_rightclick = function (pos, node, player, pointed_thing)
        local pos = player:getpos()
        minetest.sound_play ("skittles",
            { pos=pos, gain = 2.0, max_hear_distance = 5000 })
    end
})

























