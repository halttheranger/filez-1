minetest.register_tool(":quests:tool", {
	description = "tool for moveing quests",
	inventory_image = "quests_tool.png",
	tool_capabilities = {
		max_drop_level = 0,
		groupcaps = {
			quests = {times={}, uses=10000, maxlevel=0}
		}
	}
})

minetest.register_node(":quests:1", {
	description = "peasant",
	mesh = "npcf.x",
	tiles = {"quest_1.png"},
	groups = {quest=1},
	visual_size ={x=0.1, y=0.2, z=0.1},
        collision_box = {x=0.1, y=0.2, z=0.1},
--	sounds = none,
	drawtype = "mesh",
	paramtype = "light",
	paramtype2 = "facedir",
on_rightclick = function(pos, node, puncher, itemstack, pointed_thing)
        local wieldname = itemstack:get_name()
        local fdir_to_fwd = { {0, -1}, {-1, 0}, {0, 1}, {1, 0} }
        local fdir = node.param2
        local pos_drop = { x=pos.x+fdir_to_fwd[fdir+1][1], y=pos.y, z=pos.z+fdir_to_fwd[fdir+1][2] }
        if wieldname == "quests:delicious_bread" then
            itemstack:take_item()
            minetest.spawn_item(pos_drop, "quests:starfell_sword_hilt")
            minetest.sound_play("thankyou", {
                pos=pos, max_hear_distance = 5
                        })
                        minetest.chat_send_player(puncher:get_player_name(), "Thank you! heres something i found during my travels nomnomnom... ")
            return itemstack
        else
            minetest.chat_send_player(puncher:get_player_name(), "i miss my homeland, the bread there was delicious")
        end
    end
})

minetest.register_tool(":quests:tool", {
	description = "tool for moveing quests",
	inventory_image = "quests_tool.png",
	tool_capabilities = {
		max_drop_level = 0,
		groupcaps = {
			quests = {times={}, uses=10000, maxlevel=0}
		}
	}
})

minetest.register_node(":quests:2", {
	description = "blacksmith",
	mesh = "character.b3d",
	tiles = {"quest_2.png"},
	groups = {quest=1},
--	sounds = none,
	drawtype = "nodebox",
	paramtype = "light",
	paramtype2 = "facedir",
	on_rightclick = function(pos, node, puncher, pointed_thing)
		local wielditem = puncher:get_wielded_item()
		local wieldname = wielditem:get_name()
		local fdir_to_fwd = { {0, -1}, {-1, 0}, {0, 1}, {1, 0} }
		local fdir = node.param2
		local pos_drop = { x=pos.x+fdir_to_fwd[fdir+1][1], y=pos.y, z=pos.z+fdir_to_fwd[fdir+1][2] }
		if wieldname == "quests:hammer" then
			wielditem:take_item()
			puncher:set_wielded_item(wielditem)
			minetest.spawn_item(pos_drop, "quests:starfell_ore")
			minetest.sound_play("put a noise here!", {
				pos=pos, max_hear_distance = 5
                        })
                        minetest.chat_send_player(puncher:get_player_name(), "thank you. heres some starfell ore, i heard that the blacksmith at Drenpost in Ekatha can make this into something useful")
			
		else
			minetest.chat_send_player(puncher:get_player_name(), "grrr i broke my favorite hammer, get me a new one and ill make it worth your time")
		end
	end
})
minetest.register_craftitem(":quests:delicious_bread", {
	description = "forgien bread",
	inventory_image = "quests_delicious_bread.png",
})

minetest.register_craftitem(":quests:hammer", {
	description = "blacksmith's hammer",
	inventory_image = "quests_hammer.png",
})
minetest.register_craftitem(":quests:starfell_ore", {
	description = "ore from the sky",
	inventory_image = "quests_starfell_ore.png",
})
minetest.register_craftitem(":quests:starfell_sword_blade", {
	description = "the first piece of the starfell blade",
	inventory_image = "quests_starfell_sword_blade.png",
})
minetest.register_craftitem(":quests:starfell_sword_hilt", {
	description = "the second piece of the starfell blade",
	inventory_image = "quests_starfell_sword_hilt.png",
})
minetest.register_craftitem(":quests:starfell_sword_scabberd", {
	description = "the third and final piece of the starfell blade",
	inventory_image = "quests_starfell_sword_scabberd.png",
})
minetest.register_craftitem(":quests:life", {
	description = "give an artifact blade life and a special ability!",
	inventory_image = "quests_life.png",
})


























