minetest.register_node(":admin:barricade", {
	drawtype = "nodebox",
        inventory_image = "barricade image",
	tiles = {"admin_barricade.png"},
	sunlight_propagates = true,
	walkable = true,
	groups = {not_in_creative_inventory=1, immortal=1},
})
