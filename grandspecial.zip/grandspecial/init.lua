dofile(minetest.get_modpath("grandspecial").."/music.lua")
dofile(minetest.get_modpath("grandspecial").."/quests.lua")
dofile(minetest.get_modpath("grandspecial").."/admin.lua")
dofile(minetest.get_modpath("grandspecial").."/weapons.lua")
































--minetest.register_chatcommand("music", {
--	params = "music",
--	description = "start music",
--	privs = {server = true},
--	func = function(music, stuff)
--                minetest.sound_play("test",{
--                        pos = {x=0, y=0, z=0},
--                        max_hear_distance = 25,
--                        gain = 10,
--                        loop = true})
--        end})
--
--local handle = minetest.sound_play("music", {
--        pos = {x=0, y=0, z=0}
--	loop = true}})
--
--minetest.register_chatcommand("music_stop", {
--        params = "music",
--        description = "stop_music",
--        privs = {server = true},
--        func = function(music, handle)
 
--minetest.after(60, function(handle)
--	minetest.sound_stop(handle)
--end, handle)


























