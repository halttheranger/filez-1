minetest.register_tool(":weapons:starfell_sword", {
	description = "Starfell Sword",
	inventory_image = "weapons_starfell_sword.png",
	tool_capabilities = {
		full_punch_interval = 0.01,
		max_drop_level = 0,
		groupcaps = {
			snappy = {times={[1]=0.05, [2]=0.005, [3]=0.0005}, uses = 0, maxlevel=1},
		},
		damage_groups = {fleshy=25, immortal=15},
	}
})
                


























